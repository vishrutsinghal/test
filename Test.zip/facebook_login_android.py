import os
import unittest
from appium import webdriver
from time import sleep
from appium.webdriver.common.touch_action import TouchAction


# Returns abs path relative to this file and not cwd
PATH = lambda p: os.path.abspath(
    os.path.join(os.path.dirname(__file__), p)
)

"""
Using ludo app login as facebook feature to login in to app.
"""

class ContactsAndroidTests(unittest.TestCase):
    def setUp(self):
        desired_caps = {}
        desired_caps['platformName'] = 'Android'
        desired_caps['platformVersion'] = '6.1.1'
        desired_caps['deviceName'] = ''
        desired_caps['app'] = PATH(
            'D:/PD/sublime_code/Appium_python/sampletest_scenario/ludostar_v35.apk'
        )

        self.driver = webdriver.Remote('http://localhost:4723/wd/hub', desired_caps)
        expected_username = "xxx"

    def tearDown(self):
        self.driver.quit()

    def test_add_contacts(self):

        #click on facebook element
        el1 = self.driver.find_element_by_xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View")
        el1.click()

        #in my case i have already logged in, so checking the account details.

        acc_button = self.driver.find_element_by_accessibility_id('acc_home')
        acc_button.click()

    def test_account_details(self):
        val_username = self.driver.find_element_by_accessibility_id('username')
        assert val_username = expected_username

if __name__ == '__main__':
    suite = unittest.TestLoader().loadTestsFromTestCase(ContactsAndroidTests)
    unittest.TextTestRunner(verbosity=2).run(suite)
